# HealthMate AI 🏥

AI-powered healthcare companion MVP for a 24–48 hour hackathon.

## Included
- Flutter mobile UI
- FastAPI backend
- Safety-first AI endpoint
- OCR report upload/extraction
- Local reminder notifications
- Healthcare search API placeholder
- Firebase dependencies ready for Auth/Firestore/Storage integration

## Run backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --port 8000
```
Tesseract OCR must be installed on the machine, or use the included Dockerfile.

## Run Flutter
```bash
cd mobile
flutter pub get
flutter run
```
For a physical Android device, pass your computer's LAN URL:
```bash
flutter run --dart-define=API_URL=http://YOUR_COMPUTER_IP:8000
```
For Android emulator, the default `http://10.0.2.2:8000` works.

## Firebase
Create a Firebase project, enable Authentication/Firestore/Storage, then run FlutterFire CLI to generate `firebase_options.dart` and initialize Firebase in `main.dart`. The dependencies are already included.

## AI provider
Set `AI_API_URL`, `AI_API_KEY`, and `AI_MODEL` in `backend/.env` for an OpenAI-compatible chat endpoint. Without these, the app runs in safe demo mode.

## Important
This is a hackathon MVP, not a medical device. Do not use real patient data during a demo. Use synthetic/demo reports. The app does not diagnose, prescribe, or replace professional care.
