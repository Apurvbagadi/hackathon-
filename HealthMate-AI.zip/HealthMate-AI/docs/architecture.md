# Architecture

Flutter -> FastAPI -> AI/OCR/services

Firebase can provide production authentication, Firestore persistence and Storage.
Maps/Places can provide healthcare navigation.

Safety flow: user input -> safety checks -> AI -> response -> user.
