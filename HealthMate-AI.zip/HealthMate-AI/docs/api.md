# API

POST /api/chat
POST /api/reports/upload
GET /api/reports
POST /api/reminders
GET /api/reminders
DELETE /api/reminders/{id}
GET /api/healthcare/nearby?lat=&lng=&kind=hospital
GET /health
