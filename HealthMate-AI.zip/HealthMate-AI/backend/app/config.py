from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "HealthMate AI API"
    cors_origins: str = "*"
    ai_api_url: str = ""
    ai_api_key: str = ""
    ai_model: str = "gpt-4o-mini"
    google_maps_api_key: str = ""
    firebase_credentials_path: str = ""
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
