DANGEROUS_PATTERNS = [
    "change my dosage", "increase my dose", "decrease my dose",
    "prescribe", "diagnose me", "what medicine should i take",
]

EMERGENCY_TERMS = [
    "can't breathe", "cannot breathe", "difficulty breathing", "chest pain",
    "severe bleeding", "unconscious", "stroke symptoms", "suicide", "overdose",
]

def assess_message(message: str) -> dict:
    text = message.lower().strip()
    emergency = any(term in text for term in EMERGENCY_TERMS)
    restricted = any(term in text for term in DANGEROUS_PATTERNS)
    return {"emergency": emergency, "restricted": restricted}

def safe_fallback(message: str, assessment: dict) -> str:
    if assessment["emergency"]:
        return ("This may describe a medical emergency. Please seek immediate professional "
                "medical help or contact your local emergency services. HealthMate AI cannot "
                "assess or treat an emergency.")
    if assessment["restricted"]:
        return ("I can provide general educational information, but I can't diagnose you, "
                "prescribe medication, or recommend changing a medicine dose. Please speak "
                "with a qualified healthcare professional.")
    return ("I can explain general health information in simple language. For personal "
            "medical decisions, please consult a qualified healthcare professional.")
