import httpx
from app.config import settings
from app.services.safety import assess_message, safe_fallback

SYSTEM_PROMPT = """You are HealthMate AI, an educational healthcare information assistant.
Explain general health concepts in simple language. Do not diagnose diseases, prescribe
medications, recommend changing medication doses, or claim to be a doctor. For urgent or
emergency situations, tell the user to seek professional emergency care. Clearly distinguish
educational information from personal medical advice. Keep responses concise and practical."""

async def chat(message: str) -> dict:
    assessment = assess_message(message)
    if assessment["emergency"] or assessment["restricted"]:
        return {"reply": safe_fallback(message, assessment), "safety_flag": True}

    if not settings.ai_api_url or not settings.ai_api_key:
        return {"reply": safe_fallback(message, assessment), "safety_flag": False, "demo_mode": True}

    headers = {"Authorization": f"Bearer {settings.ai_api_key}", "Content-Type": "application/json"}
    payload = {
        "model": settings.ai_model,
        "messages": [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": message}],
        "temperature": 0.2,
    }
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(settings.ai_api_url, headers=headers, json=payload)
        response.raise_for_status()
        data = response.json()
    reply = data.get("choices", [{}])[0].get("message", {}).get("content", "")
    return {"reply": reply or safe_fallback(message, assessment), "safety_flag": False}
