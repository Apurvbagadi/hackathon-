from pathlib import Path
from PIL import Image
import pytesseract


def extract_text(file_path: str) -> str:
    try:
        return pytesseract.image_to_string(Image.open(file_path)).strip()
    except Exception as exc:
        raise RuntimeError(f"OCR failed: {exc}") from exc


def summarize_text(text: str) -> str:
    if not text:
        return "No readable text was detected. Please upload a clearer image."
    preview = text[:1200]
    return ("Demo report summary:\n\n" + preview +
            "\n\nThis is an OCR-based extraction, not a medical interpretation. "
            "Please have a qualified healthcare professional interpret your results.")
