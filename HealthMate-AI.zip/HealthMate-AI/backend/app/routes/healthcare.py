from fastapi import APIRouter, Query

router = APIRouter(prefix="/api/healthcare", tags=["Healthcare"])

@router.get("/nearby")
def nearby(lat: float = Query(...), lng: float = Query(...), kind: str = "hospital"):
    # Demo response. Replace with Google Places/Maps or another approved provider in production.
    return {"kind": kind, "center": {"lat": lat, "lng": lng}, "places": []}
