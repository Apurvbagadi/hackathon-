from datetime import datetime
from uuid import uuid4
from fastapi import APIRouter
from pydantic import BaseModel, Field

router = APIRouter(prefix="/api/reminders", tags=["Reminders"])
_store = []

class Reminder(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    description: str = ""
    date: str
    time: str
    type: str = "general"

@router.post("")
def create_reminder(item: Reminder):
    record = {"id": str(uuid4()), **item.model_dump()}
    _store.append(record)
    return record

@router.get("")
def get_reminders():
    return _store

@router.delete("/{reminder_id}")
def delete_reminder(reminder_id: str):
    global _store
    _store = [r for r in _store if r["id"] != reminder_id]
    return {"deleted": True}
