import tempfile
from fastapi import APIRouter, UploadFile, File, HTTPException
from app.services.ocr_service import extract_text, summarize_text

router = APIRouter(prefix="/api/reports", tags=["Reports"])

@router.post("/upload")
async def upload_report(file: UploadFile = File(...)):
    allowed = {"image/jpeg", "image/png", "image/webp"}
    if file.content_type not in allowed:
        raise HTTPException(400, "Please upload a JPG, PNG, or WebP image.")
    data = await file.read()
    if len(data) > 10 * 1024 * 1024:
        raise HTTPException(413, "File is larger than 10 MB.")
    suffix = ".png" if file.content_type == "image/png" else ".jpg"
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=True) as tmp:
        tmp.write(data)
        tmp.flush()
        try:
            text = extract_text(tmp.name)
        except RuntimeError as exc:
            raise HTTPException(500, str(exc))
    return {"filename": file.filename, "extracted_text": text, "summary": summarize_text(text)}

@router.get("")
async def get_reports():
    return []
