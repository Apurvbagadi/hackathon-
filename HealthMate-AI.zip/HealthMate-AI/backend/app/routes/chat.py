from fastapi import APIRouter
from pydantic import BaseModel, Field
from app.services.ai_service import chat

router = APIRouter(prefix="/api/chat", tags=["AI"])

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)

@router.post("")
async def chat_endpoint(request: ChatRequest):
    return await chat(request.message)
