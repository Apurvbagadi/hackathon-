import 'package:flutter/material.dart';
import 'services/reminder_service.dart';
import 'screens/home_screen.dart';

Future<void> main() async { WidgetsFlutterBinding.ensureInitialized(); await ReminderService.init(); runApp(const HealthMateApp()); }
class HealthMateApp extends StatelessWidget { const HealthMateApp({super.key}); @override Widget build(BuildContext context)=>MaterialApp(title:'HealthMate AI',debugShowCheckedModeBanner:false,theme:ThemeData(useMaterial3:true,colorSchemeSeed:Colors.teal),home:const HomeScreen()); }
