import 'package:flutter/material.dart';
import 'chat_screen.dart';
import 'report_screen.dart';
import 'reminders_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('HealthMate AI')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('Your healthcare companion', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Understand health information. Organize reports. Remember appointments.'),
      const SizedBox(height: 24),
      _Card(icon: Icons.smart_toy, title: 'AI Health Assistant', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ChatScreen()))),
      _Card(icon: Icons.description, title: 'Medical Report Explainer', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ReportScreen()))),
      _Card(icon: Icons.notifications, title: 'Reminders', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RemindersScreen()))),
      _Card(icon: Icons.local_hospital, title: 'Find Healthcare', onTap: () => _showInfo(context, 'Healthcare search is ready for Maps/Places API integration.')),
      _Card(icon: Icons.emergency, title: 'Emergency', onTap: () => _showInfo(context, 'If this is an emergency, contact local emergency services and seek immediate professional care.')),
      const SizedBox(height: 16),
      const Text('Safety: HealthMate AI provides educational information and does not diagnose or prescribe.'),
    ]),
  );
}
class _Card extends StatelessWidget {
  final IconData icon; final String title; final VoidCallback onTap;
  const _Card({required this.icon, required this.title, required this.onTap});
  @override Widget build(BuildContext context) => Card(child: ListTile(leading: Icon(icon), title: Text(title), trailing: const Icon(Icons.chevron_right), onTap: onTap));
}
void _showInfo(BuildContext c, String s) => showDialog(context: c, builder: (_) => AlertDialog(title: const Text('HealthMate AI'), content: Text(s), actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('OK'))]));
