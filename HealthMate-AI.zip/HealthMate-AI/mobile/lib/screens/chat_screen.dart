import 'package:flutter/material.dart';
import '../services/api_service.dart';

class ChatScreen extends StatefulWidget { const ChatScreen({super.key}); @override State<ChatScreen> createState() => _ChatScreenState(); }
class _ChatScreenState extends State<ChatScreen> {
  final controller = TextEditingController(); final messages = <Map<String,String>>[]; bool loading = false;
  Future<void> send() async { final text = controller.text.trim(); if (text.isEmpty || loading) return; controller.clear(); setState(() { messages.add({'role':'user','text':text}); loading=true; }); try { final r = await ApiService.chat(text); setState(() => messages.add({'role':'ai','text':r['reply'] ?? ''})); } catch(e) { setState(() => messages.add({'role':'ai','text':'Could not connect to the backend. Make sure FastAPI is running.'})); } finally { setState(() => loading=false); } }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('AI Health Assistant')), body: Column(children: [Expanded(child: ListView.builder(padding: const EdgeInsets.all(12), itemCount: messages.length, itemBuilder: (_,i){ final m=messages[i]; return Align(alignment:m['role']=='user'?Alignment.centerRight:Alignment.centerLeft, child: Card(child: Padding(padding:const EdgeInsets.all(12), child: Text(m['text']!))); })), if(loading) const Padding(padding:EdgeInsets.all(8), child:CircularProgressIndicator()), Padding(padding: const EdgeInsets.all(12), child: Row(children:[Expanded(child:TextField(controller:controller, decoration:const InputDecoration(hintText:'Ask a general health question'))), IconButton(onPressed:send, icon:const Icon(Icons.send))]))]));
}
