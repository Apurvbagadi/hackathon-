import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/api_service.dart';

class ReportScreen extends StatefulWidget { const ReportScreen({super.key}); @override State<ReportScreen> createState()=>_ReportScreenState(); }
class _ReportScreenState extends State<ReportScreen> { String result=''; bool loading=false;
Future<void> pick() async { final x=await ImagePicker().pickImage(source:ImageSource.gallery); if(x==null)return; setState(()=>loading=true); try { final r=await ApiService.uploadReport(File(x.path)); setState(()=>result='${r['summary']}\n\nExtracted text:\n${r['extracted_text']}'); } catch(e){setState(()=>result='Upload/OCR failed. Check the backend and Tesseract installation.');} finally{setState(()=>loading=false);} }
@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Report Explainer')),body:Padding(padding:const EdgeInsets.all(20),child:Column(children:[ElevatedButton.icon(onPressed:loading?null:pick,icon:const Icon(Icons.upload_file),label:const Text('Upload Report Image')),const SizedBox(height:20),if(loading)const CircularProgressIndicator(),Expanded(child:SingleChildScrollView(child:Text(result.isEmpty?'Upload a synthetic/demo report image to test OCR.':result)))])));
}
